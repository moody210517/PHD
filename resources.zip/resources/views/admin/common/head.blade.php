<meta charset="utf-8" />
  <title>Proactive Health Detection(IOT)</title>
  <meta name="description" content="Responsive, Bootstrap, BS4" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />  
  <meta name="csrf-token" content="{{ csrf_token() }}"/>
  <meta name="google" content="notranslate">

  <!-- style -->
  <!-- build:css {{ asset('assets/css/site.min.css') }}  -->
  <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.css') }} " type="text/css" />
  <link rel="stylesheet" href="{{ asset('assets/css/i-con.css') }} " type="text/css" />
  <link rel="stylesheet" href="{{ asset('assets/css/theme.css') }} " type="text/css" />
  <link rel="stylesheet" href="{{ asset('assets/css/style.css') }} " type="text/css" />
  <link rel="stylesheet" href="{{ asset('assets/toastr/css/toastr.css') }} " type="text/css" />
